String name = "Chris B. Behrens";
int courseCount = 14;
BigDecimal salary = 99999999.99;
Boolean isProgrammer = true;

println name + " has created " + courseCount + " courses.";
println name + " is a programmer? " + isProgrammer.toString().capitalize();
println name + " wishes his salary was \$" + salary;