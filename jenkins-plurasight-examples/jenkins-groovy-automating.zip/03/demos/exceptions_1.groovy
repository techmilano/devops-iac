try{
    def x = 1/0;
    println(x);
}catch(ex){
    println(ex);
}