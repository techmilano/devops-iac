# jenkins-pipeline-demo-library

Living source code at https://github.com/sixeyed/jenkins-pipeline-demo-library