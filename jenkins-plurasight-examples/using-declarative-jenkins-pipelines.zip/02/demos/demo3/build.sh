#!/bin/sh
echo "Using API key: $API_KEY"