#!/bin/sh
echo "Inside the script, demo $DEMO"